package com.example.myfinancesapp

data class CheckingAccount(
    val accountNumber: String,
    val currentBalance: Double
)